package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.CommonActions;

public class Polaris_Industrial_Mean_Page extends TestBase {

    // Navigation controls

    @FindBy(xpath = "//button[@class='btn btn-default btn-xs']")
    @CacheLookup
    WebElement _expandbutton;

    @FindBy(xpath = "//a[text()='Industrial means']")
    @CacheLookup
    WebElement _industrialmean;

    // Industrial Means Controls

    @FindBy(xpath = "//a[@title='Add new industrial means']")
    @CacheLookup
    WebElement _Addbutton;

    @FindBy(xpath = "//div[@po-title='Industrial means']")
    @CacheLookup
    WebElement _industrialmeanLabel;

    @FindBy(xpath = "//th[text()='Code']")
    @CacheLookup
    WebElement _codeColumn;

    @FindBy(xpath = "//div[@po-title='Create new industrial means']")
    @CacheLookup
    WebElement _createNewIndustrialMeanLable;

    @FindBy(xpath = "//button[@class='btn btn-primary btn-xs']//span[@class='glyphicon glyphicon-plus']")
    @CacheLookup
    WebElement _plusButton;

    @FindBy(xpath = "//input[@name='codeInput']")
    @CacheLookup
    WebElement _code;

    @FindBy(xpath = "//input[@name='supplyCodeInput']")
    @CacheLookup
    WebElement _suppy;

    @FindBy(xpath = "//textarea[@name='descriptionInput']")
    @CacheLookup
    WebElement _description;

    @FindBy(xpath = "//input[@value='grouping']")
    @CacheLookup
    WebElement _grouping;

    @FindBy(xpath = "//input[@value='UPSTREAM']")
    @CacheLookup
    WebElement _upstream;

    @FindBy(xpath = "//select[@id='mpsSectorConfigurationInput']")
    @CacheLookup
    WebElement _sector;

    // Checkbox

    @FindBy(xpath = "//input[@id='rateDependent']")
    @CacheLookup
    WebElement _familyRate;

    @FindBy(xpath = "//input[@id='criticalSOP']")
    @CacheLookup
    WebElement _snopCriticalCheckbox;

    @FindBy(xpath = "//input[@id='mpsFamilyEnable']")
    @CacheLookup
    WebElement _mpsFamily;

    @FindBy(xpath = "//input[@id='dayLeadTime']")
    @CacheLookup
    WebElement _days;

    @FindBy(xpath = "//button[@type='submit']")
    @CacheLookup
    WebElement _Save;

    // Checkpoint

    @FindBy(xpath = "//span[text()='AGADEP']")
    @CacheLookup
    WebElement _cretedmean;

    @FindBy(xpath = "//p[text()='New industrial means  has been added!']")
    @CacheLookup
    WebElement _sucessmessage;

    @FindBy(xpath = "//a[@title='Back']")
    @CacheLookup
    WebElement _backbtn;

    // Detail view

    @FindBy(xpath = "//a[text()='Levels']")
    @CacheLookup
    WebElement _levels;

    @FindBy(xpath = "//a[text()='Clients Configuration']")
    @CacheLookup
    WebElement _clientconfig;

    @FindBy(xpath = "//a[text()='Product family']")
    @CacheLookup
    WebElement _productfamily;

    @FindBy(xpath = "//a[text()='Product']")
    @CacheLookup
    WebElement _product;

    @FindBy(xpath = "//a[text()='MPS Family']")
    @CacheLookup
    WebElement _mpsfamily;

    // Mps Family

    @FindBy(xpath = "//a[@title='Add a MPS Group to industrial means AUTOMATION']")
    @CacheLookup
    WebElement _mpsfamilyaddbutton;

    @FindBy(xpath = "//div[@class='modal-content']//input[@id='code']")
    @CacheLookup
    WebElement _mpsFamilyCodetextbox;

    @FindBy(xpath = "//div[@class='modal-dialog']//span[@class='glyphicon glyphicon-ok']")
    @CacheLookup
    WebElement _savebutton;

    @FindBy(xpath = "//div[@class='modal-content']//button[@data-ng-click='valid()']")
    @CacheLookup
    WebElement _saveMPSbutton;

    @FindBy(xpath = "//div[@id='mpsGroupMsgBox']//button[@data-ng-click='poYesClick()']")
    @CacheLookup
    WebElement _saveAlertMPSbutton;

    // Child Industrial Mean

    @FindBy(xpath = "//a[@title='Add child in industrial means AUTOMATION']")
    @CacheLookup
    WebElement _addChildbutton;

    @FindBy(xpath = "//div[@class='form-group']//span[@class='glyphicon glyphicon-plus']")
    @CacheLookup
    WebElement _addMoreInfobutton;

    @FindBy(xpath = "//select[@id='schedulingTypeConfigurationInput']")
    @CacheLookup
    WebElement _sequenceDropDown;

    @FindBy(xpath = "//label[contains(.,'Increasing')]")
    @CacheLookup
    WebElement _increasingCheckbox;

    @FindBy(xpath = "//p[text()='New industrial means  has been added in industrial means AUTOMATION!']")
    @CacheLookup
    WebElement _sucessmessageChildIM;

    @FindBy(xpath = "//input[@name='codeInput']")
    @CacheLookup
    WebElement _codeChild;

    @FindBy(xpath = "//input[@name='supplyCodeInput']")
    @CacheLookup
    WebElement _suppyChild;

    @FindBy(xpath = "//textarea[@name='descriptionInput']")
    @CacheLookup
    WebElement _descriptionChild;

    @FindBy(xpath = "//button[@type='submit']")
    @CacheLookup
    WebElement _SaveChild;

    @FindBy(xpath = "//div[@class='modal-dialog']//span[@class='glyphicon glyphicon-ok']")
    @CacheLookup
    WebElement _saveChildbuttonPop;

    @FindBy(xpath = "//a[text()='Industrial means']")
    @CacheLookup
    WebElement _industrialmeanChild;

    @FindBy(xpath = "//div[@po-title='Industrial means']")
    @CacheLookup
    WebElement _industrialmeanLabelChild;

    @FindBy(xpath = "//button[@title='Expand all']")
    @CacheLookup
    WebElement _expandButton;

    // Delete IM

    @FindBy(xpath = "//div[@class='modal-dialog']//button[@class='btn btn-success']")
    @CacheLookup
    WebElement _deleteIMButton;

    @FindBy(xpath = "//button[@class='btn btn-success']")
    @CacheLookup
    WebElement _Yesbutton;

    // Initialise the Page Objects
    public Polaris_Industrial_Mean_Page() {
        PageFactory.initElements(driver, this);
    }

    public void createIndustrialMean(String Code, String Supply, String Description, String Type, String Topology, String Sector,
            String FamilyDependentRate, String SnOPCriticalMeans, String MPSConstraintActivation, String ManufacturingLeadtime, String MPSCode,
            String ChildCode, String ChildSupply, String ChildDesc, String SeqType) {
        try {

            _expandbutton.click();
            _expandbutton.isEnabled();
            CommonActions.waitforcontrol(driver, _industrialmean);
            _industrialmean.isEnabled();
            _industrialmean.click();

            CommonActions.waitforcontrol(driver, _industrialmeanLabel);
            _Addbutton.isEnabled();
            _Addbutton.click();
            CommonActions.waitforcontrol(driver, _createNewIndustrialMeanLable);
            _plusButton.isEnabled();
            _plusButton.click();
            CommonActions.waitforcontrol(driver, _createNewIndustrialMeanLable);
            _code.isEnabled();
            _code.sendKeys(Code);

            _suppy.isEnabled();
            _suppy.sendKeys(Supply);

            _description.isEnabled();
            _description.sendKeys(Description);

            if (Type.equalsIgnoreCase("Grouping")) {
                _grouping.click();
            }
            if (Topology.equalsIgnoreCase("Upstream")) {
                _upstream.click();
            }

            CommonActions.SelectSGRDropdown(driver, _sector, Sector);

            if (FamilyDependentRate.equalsIgnoreCase("Yes")) {
                _familyRate.click();
            }

            if (SnOPCriticalMeans.equalsIgnoreCase("Yes")) {
                _snopCriticalCheckbox.click();
            }

            if (MPSConstraintActivation.equalsIgnoreCase("MPS Family")) {
                _mpsFamily.click();
            }

            _days.isEnabled();
            _days.clear();

            String sample = ManufacturingLeadtime.toString();

            String last = sample.substring(0, 1);

            _days.sendKeys(last);

            _Save.isEnabled();
            _Save.click();
            Thread.sleep(2000);
            if (_savebutton.isDisplayed()) {
                _savebutton.click();
            }

            CommonActions.waitforcontrol(driver, _sucessmessage);
            _industrialmean.isEnabled();
            _industrialmean.click();

        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Validate Client created
    public boolean validateIndustrialMean(String code) throws InterruptedException {
        boolean i = false;

        WebElement _family = driver.findElement(By.xpath("//span[text()='" + code + "']"));
        CommonActions.waitforcontrol(driver, _family);
        if (_family.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    // Validate Client created
    public boolean validateIndustrialMean2(String code) throws InterruptedException {
        boolean i = false;

        WebElement _family2 = driver.findElement(By.xpath("//span[text()='" + code + "']"));
        CommonActions.waitforcontrol(driver, _family2);
        if (_family2.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    public String checkindustrialmeancreated(String code) throws InterruptedException {
        WebElement _family = driver.findElement(By.xpath("//span[text()='" + code + "']"));
        CommonActions.waitforcontrol(driver, _family);
        return _family.getText();
    }

    // Validate Client created
    public boolean validateIndustrialMeanMessage() {
        boolean i = false;

        if (_sucessmessage.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    // CLick on Validate button
    public void clickViewButton(String code) {

        WebElement elemTable = driver.findElement(By.xpath("//a[@title='Consult industrial means " + code + "']"));
        if (elemTable.isDisplayed()) {
            elemTable.click();
            System.out.println("Element found successfully.");
        } else {
            System.out.println("Element not found.");
        }

    }

    public void createChildIM(String ChildCode, String ChildSupply, String ChildDesc, String SeqType) {
        try {
            CommonActions.waitforcontrol(driver, _addChildbutton);
            _addChildbutton.isEnabled();
            _addChildbutton.click();
            CommonActions.waitforcontrol(driver, _addMoreInfobutton);
            _addMoreInfobutton.isEnabled();
            _addMoreInfobutton.click();

            try {
                _codeChild.isEnabled();
                _codeChild.click();
                _codeChild.sendKeys(ChildCode);
            } catch (org.openqa.selenium.StaleElementReferenceException ex) {
                _codeChild.isEnabled();
                _codeChild.click();
                _codeChild.sendKeys(ChildCode);
            }

            try {
                _suppyChild.isEnabled();
                _suppyChild.sendKeys(ChildSupply);
            } catch (org.openqa.selenium.StaleElementReferenceException ex) {
                _suppyChild.isEnabled();
                _suppyChild.sendKeys(ChildSupply);
            }

            try {
                _descriptionChild.isEnabled();
                _descriptionChild.sendKeys(ChildDesc);
            } catch (org.openqa.selenium.StaleElementReferenceException ex) {
                _descriptionChild.isEnabled();
                _descriptionChild.sendKeys(ChildDesc);
            }

            CommonActions.SelectSGRDropdown(driver, _sequenceDropDown, SeqType);

            _increasingCheckbox.isEnabled();
            _increasingCheckbox.click();
            _SaveChild.isEnabled();
            _SaveChild.click();

            CommonActions.waitforcontrol(driver, _saveChildbuttonPop);

            if (_saveChildbuttonPop.isDisplayed()) {
                _saveChildbuttonPop.isEnabled();
                _saveChildbuttonPop.click();
            }

            CommonActions.waitforcontrol(driver, _sucessmessageChildIM);

            _industrialmeanChild.isEnabled();
            _industrialmeanChild.click();

            CommonActions.waitforcontrol(driver, _expandButton);

            _expandButton.isEnabled();
            _expandButton.click();

        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean validateChildIndustrialMeanMessage() {
        boolean i = false;

        if (_sucessmessageChildIM.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    public void createMPSFamily(String MPSCode) {
        try {
            CommonActions.waitforcontrol(driver, _mpsfamily);
            _mpsfamily.isEnabled();
            _mpsfamily.click();
            CommonActions.waitforcontrol(driver, _mpsfamilyaddbutton);
            _mpsfamilyaddbutton.isEnabled();
            _mpsfamilyaddbutton.click();
            CommonActions.waitforcontrol(driver, _mpsFamilyCodetextbox);
            _mpsFamilyCodetextbox.isEnabled();
            _mpsFamilyCodetextbox.click();
            _mpsFamilyCodetextbox.sendKeys(MPSCode);
            Thread.sleep(3000);

            _saveMPSbutton.isEnabled();
            _saveMPSbutton.click();
            Thread.sleep(5000);
            if (_saveAlertMPSbutton.isDisplayed()) {
                _saveAlertMPSbutton.click();
            }

            CommonActions.waitforcontrol(driver, _mpsFamilyCodetextbox);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Validate MPS Family
    public boolean validateMPSFamily(String MPScode) {
        boolean i = false;

        WebElement _family = driver.findElement(By.xpath("//td[text()='" + MPScode + "']"));

        if (_family.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    // Delete Industrial Mean
    public void clickDeleteButton(String IMcode) throws InterruptedException {

        _expandbutton.click();
        _expandbutton.isEnabled();
        CommonActions.waitforcontrol(driver, _industrialmean);
        _industrialmean.isEnabled();
        _industrialmean.click();
        CommonActions.waitforcontrol(driver, _industrialmeanLabel);

        WebElement elemTable = driver.findElement(By.xpath("//a[@title='Delete industrial means " + IMcode + "']"));
        if (elemTable.isDisplayed()) {
            elemTable.click();
            System.out.println(IMcode + "Element found successfully.");
        } else {
            System.out.println(IMcode + "Element not found.");
        }

        if (_Yesbutton.isEnabled()) {
            _Yesbutton.isEnabled();
            _Yesbutton.click();
        }

        WebElement _deleteIMmessage = driver.findElement(By.xpath("//p[text()='Industrial means " + IMcode + " has been deleted!']"));
        CommonActions.waitforcontrol(driver, _deleteIMmessage);

    }

    // Validate Industrial Mean Deleted
    public boolean validateIMDeleted(String IMcode) throws InterruptedException {
        boolean i = true;

        WebElement _deletedImcode = driver.findElement(By.xpath("//span[text()='" + IMcode + "']"));
        CommonActions.waitforcontrol(driver, _deletedImcode);
        if (_deletedImcode.isDisplayed()) {

            i = false;
            return i;
        }
        return i;
    }

}
