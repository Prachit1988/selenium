package com.qa.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.CommonActions;

public class Polaris_Home_Page extends TestBase {

    // Page Factory

    @FindBy(xpath = "//button[@class='btn btn-default btn-xs']")
    @CacheLookup
    WebElement _collapsebutton;

    @FindBy(xpath = "//a[@class='logo']")
    @CacheLookup
    WebElement _logo;

    @FindBy(xpath = "//a[@id='ddlanguage-link']")
    @CacheLookup
    WebElement _language;

    @FindBy(xpath = "//ul[@id='ddlanguage-menu']//a[text()='English']")
    @CacheLookup
    WebElement _English;

    @FindBy(xpath = "//ul[@id='ddlanguage-menu']//a[text()='Français (France)']")
    @CacheLookup
    WebElement _French;

    @FindBy(xpath = "//a[@title='Recheck connectivity']")
    @CacheLookup
    WebElement _onlinePresence;

    @FindBy(xpath = "//a[@id='ddprofile-link']//b[@class='caret']")
    @CacheLookup
    WebElement _UserDropdown;

    @FindBy(xpath = "//div[@class='panel-body']//h4[text()='Roles']")
    @CacheLookup
    WebElement _Role;

    @FindBy(xpath = "//div[@class='input-group']//select")
    @CacheLookup
    WebElement _SGRDropdown;

    @FindBy(xpath = "//option[text()='7D1 - FRANCAISE DE MECANIQUE']")
    @CacheLookup
    WebElement _SGROption;

    @FindBy(xpath = "//button[@class='btn btn-default btn-xs']")
    @CacheLookup
    WebElement _expandbutton;

    @FindBy(xpath = "//a[text()='Potential clients']")
    @CacheLookup
    WebElement _potentialclient;

    // Initialise the Page Objects
    public Polaris_Home_Page() {
        PageFactory.initElements(driver, this);
    }

    // Validate Page Title
    public String ValidateTitleofPagePolaris() {
        System.out.println(driver.getTitle());
        return driver.getTitle();
    }

    // Wait till page load
    public void waitfornavigation() throws InterruptedException {
        CommonActions.waitforcontrol(driver, _collapsebutton);
    }

    // Validate Logo on header
    public boolean validateLogo() {
        boolean i = false;

        if (_logo.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    // Validate Language Option on header
    public boolean validateLanguage() {
        boolean i = false;

        if (_language.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    // Validate Online presence on header
    public boolean validateOnlinePresence() {
        boolean i = false;

        if (_onlinePresence.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

    // Verify Selected Language on Header
    public String languageSelected() throws InterruptedException {
        CommonActions.waitforcontrol(driver, _language);
        return _language.getText();
    }

    // It will select the Language on Header
    public void selectLanguage() {
        try {
            _language.isEnabled();
            _language.click();
            CommonActions.waitforcontrol(driver, _English);
            _English.isEnabled();
            _English.click();
            CommonActions.waitforcontrol(driver, _expandbutton);
            //

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // It will select the SGR
    public void selectSGR(String sgr) throws InterruptedException {

        _UserDropdown.isEnabled();
        _UserDropdown.click();
        _SGRDropdown.isEnabled();
        _SGRDropdown.isDisplayed();
        CommonActions.SelectSGRDropdown(driver, _SGRDropdown, sgr);
        CommonActions.waitforcontrol(driver, _Role);
        _Role.isEnabled();
        _Role.click();
        selectRole();
        _UserDropdown.isEnabled();
        _UserDropdown.click();

    }

    // It will check the Roles
    public void selectRole() {

        List<WebElement> list = driver.findElements(By.xpath("//input[@type='checkbox']"));

        for (WebElement el : list) {
            if (!el.isSelected()) // validate Checked property, otherwise you'll uncheck!
                el.click();
        }

    }

    public void CreatePotentialClient() {
        CommonActions.controlEnable(_potentialclient);

    }

}
