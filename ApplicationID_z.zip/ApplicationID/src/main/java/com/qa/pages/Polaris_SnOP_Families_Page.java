package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.CommonActions;

public class Polaris_SnOP_Families_Page extends TestBase {

    @FindBy(xpath = "//button[@class='btn btn-default btn-xs']")
    @CacheLookup
    WebElement _expandbutton;

    @FindBy(xpath = "//a[text()='S&OP families']")
    @CacheLookup
    WebElement _snopfamily;

    @FindBy(xpath = "//div[@po-title='S&OP families']")
    @CacheLookup
    WebElement _snopfamilyHeader;

    @FindBy(xpath = "//button[@title='Add new family']")
    @CacheLookup
    WebElement _addsnopbutton;

    @FindBy(xpath = "//select[@id='site']")
    @CacheLookup
    WebElement _factoryDropdown;

    @FindBy(xpath = "//select[@id='site']")
    @CacheLookup
    WebElement _codeTextbox;

    @FindBy(xpath = "//button[@title='Validate']")
    @CacheLookup
    WebElement _saveButton;

    @FindBy(xpath = "//a[@title='Consult family TEST']")
    @CacheLookup
    WebElement _viewButton;

    // Initialise the Page Objects
    public Polaris_SnOP_Families_Page() {
        PageFactory.initElements(driver, this);
    }

    public void createSnOPFamily(String familyname) {
        try {

            _expandbutton.click();
            _expandbutton.isEnabled();
            CommonActions.waitforcontrol(driver, _snopfamily);
            _snopfamily.isEnabled();
            _snopfamily.click();
            CommonActions.waitforcontrol(driver, _snopfamilyHeader);
            _addsnopbutton.isEnabled();
            _addsnopbutton.click();
            CommonActions.waitforcontrol(driver, _factoryDropdown);

            _codeTextbox.sendKeys(familyname);
            _saveButton.isEnabled();
            _saveButton.click();
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Validate Client created
    public boolean validateFamily(String familyname) {
        boolean i = false;

        WebElement _family = driver.findElement(By.xpath("//td[text()='" + familyname + "']"));

        if (_family.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

}
