package com.qa.pages;

import java.awt.Desktop.Action;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.TestUtil;
import com.qa.util.CommonActions;

public class CRMHome extends TestBase{

	LoginPage loginPage;
	//Page Factory
	
		@FindBy(xpath="//div[@class=\"ui basic button floating item dropdown\"]")
		@CacheLookup
		WebElement _Logooutlogo;
		
		@FindBy(xpath="//span[contains(text(), 'Log Out')]")
		@CacheLookup
		WebElement _Logoouttext;

		@FindBy(xpath="//span[contains(text(),'Calendar')]")
		@CacheLookup
		WebElement calenderlink;
		
		@FindBy(xpath="//span[contains(text(),'Contacts')]")
		@CacheLookup
		WebElement contactslink;
		
		@FindBy(xpath="//span[contains(text(),'Companies')]")
		@CacheLookup
		WebElement companieslink;
		
		@FindBy(xpath="//span[contains(text(),'Deals')]")
		@CacheLookup
		WebElement cdealsslink;
		
		@FindBy(xpath="//span[contains(text(),'Tasks')]")
		@CacheLookup
		WebElement tasklink;
		
		@FindBy(xpath="//span[contains(text(),'Cases')]")
		@CacheLookup
		WebElement caseslink;
		
		
		// Initialize the Page Objects
		public CRMHome()
		{
			PageFactory.initElements(driver, this);
			loginPage = new LoginPage();
		}
	
		// To Get the title of page
		public String pageTitle()
		{
			System.out.println(driver.getTitle());
			return driver.getTitle();
		}
		
		
		//Click on Login button
		public LoginPage clickLogout()
		{
			_Logooutlogo.click();
			
			CommonActions.waitforcontrol(driver,_Logoouttext);
			_Logoouttext.click();
			CommonActions.waitforcontrol(driver,loginPage._loginButton);
			return new LoginPage();
		}
		
		//Click on Contacts Link
		public ContactsPage clickContactlink()
		{
			contactslink.isEnabled();
			contactslink.click();
			return new ContactsPage();
		}
		
		//Click on Task link
		public TaskPage clickTasklink()
		{
			tasklink.isEnabled();
			tasklink.click();
			return new TaskPage();
		}

}
