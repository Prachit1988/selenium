package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.CommonActions;

public class Polaris_Potential_Client_Page extends TestBase {

    @FindBy(xpath = "//button[@class='btn btn-default btn-xs']")
    @CacheLookup
    WebElement _expandbutton;

    @FindBy(xpath = "//a[text()='Potential clients']")
    @CacheLookup
    WebElement _potentialclient;

    @FindBy(xpath = "//div[@po-title='Potential clients']")
    @CacheLookup
    WebElement _potentialclientHeader;

    @FindBy(xpath = "//button[@title='Add']")
    @CacheLookup
    WebElement _addbutton;

    @FindBy(xpath = "//input[@id='inputClientName']")
    @CacheLookup
    WebElement _clienttextbox;

    @FindBy(xpath = "//button[@type='submit']")
    @CacheLookup
    WebElement _checkbutton;

    // Initialise the Page Objects
    public Polaris_Potential_Client_Page() {
        PageFactory.initElements(driver, this);
    }

    public void createnewcontact(String clientname) {
        try {

            _expandbutton.click();
            _expandbutton.isEnabled();
            CommonActions.waitforcontrol(driver, _potentialclient);
            _potentialclient.isEnabled();
            _potentialclient.click();
            CommonActions.waitforcontrol(driver, _potentialclientHeader);
            _addbutton.isEnabled();
            _addbutton.click();
            CommonActions.waitforcontrol(driver, _clienttextbox);
            _clienttextbox.sendKeys(clientname);
            _checkbutton.isEnabled();
            _checkbutton.click();
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Validate Client created
    public boolean validateClient(String clientname) {
        boolean i = false;

        WebElement _client = driver.findElement(By.xpath("//td[text()='" + clientname + "']"));

        if (_client.isDisplayed()) {

            i = true;
            return i;
        }
        return i;
    }

}
