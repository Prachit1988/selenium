package com.qa.util;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonActions {

    public static WebDriver driver;

    public static String TESTDATA_SHEET_PATH = "P:\\ApplicationID\\src\\main\\java\\com\\qa\\testdata\\freeCRMData.xlsx";

    static Workbook book;
    static Sheet sheet;
    static JavascriptExecutor js;

    // This will wait for control to get enable
    public static void waitforcontrol(WebDriver driver, WebElement _element) throws InterruptedException {
        try {

            WebDriverWait wait = new WebDriverWait(driver, 20);
            // wait.until(ExpectedConditions.elementToBeClickable(_element));
            wait.until(ExpectedConditions.visibilityOf(_element));
            Thread.sleep(2000);
            System.out.println("After wait condition" + _element + "element found Successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("After wait condition" + _element + " element not found.");
        }
    }

    // Select Dropdown for Div and Span controls
    public static void SelectDropdown(WebDriver driver, WebElement _Dropdown_element, String item_text) {
        try {
            _Dropdown_element.isEnabled();
            _Dropdown_element.click();
            WebElement _Dropdown_Item_element = driver.findElement(By.xpath("//span[text()='" + item_text + "']"));
            CommonActions.waitforcontrol(driver, _Dropdown_Item_element);
            Thread.sleep(2000);
            _Dropdown_Item_element.click();
            System.out.println(item_text + "Element selected.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Element not selected.");
        }

    }

    // Select SGR Dropdown
    public static void SelectSGRDropdown(WebDriver driver, WebElement _Dropdown_element, String item_text) {
        try {
            _Dropdown_element.isEnabled();
            _Dropdown_element.click();
            WebElement _Dropdown_Item_element = driver.findElement(By.xpath("//option[text()='" + item_text + "']"));
            CommonActions.waitforcontrol(driver, _Dropdown_Item_element);
            Thread.sleep(2000);
            _Dropdown_Item_element.click();
            System.out.println(item_text + "Element selected.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Element not selected.");
        }

    }

    public static void SelectRoleOption(WebDriver driver, String item_text) {
        try {
            // _Dropdown_element.isEnabled();
            // _Dropdown_element.click();
            WebElement _Dropdown_Item_element = driver.findElement(By.xpath("//label[contains(.,'" + item_text + "')]"));
            CommonActions.waitforcontrol(driver, _Dropdown_Item_element);
            Thread.sleep(2000);
            _Dropdown_Item_element.click();
            System.out.println(item_text + "Element selected.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Element not found.");
        }

    }

    public static void controlEnable(WebElement _elementcontrol) {
        try {
            // WebElement _elementcontrol = driver.findElement(By.xpath("//label[contains(.,'" + item_text + "')]"));
            Thread.sleep(1000);
            _elementcontrol.isDisplayed();
            _elementcontrol.isEnabled();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Element not found.");
        }
    }

}
