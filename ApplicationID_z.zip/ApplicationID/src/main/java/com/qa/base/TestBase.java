package com.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.qa.util.TestUtil;

public class TestBase {

    public static WebDriver driver;
    public static Properties prop;

    public TestBase() {

        prop = new Properties();
        FileInputStream ip;
        try {
            ip = new FileInputStream("P:\\ApplicationID\\src\\main\\java\\com\\qa\\config\\config.properties");
            prop.load(ip);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void Initialization() {
        try {
            String browsername = prop.getProperty("browser");
            if (browsername.equals("chrome")) {

                System.setProperty("webdriver.chrome.driver", "P:\\Selenium_Project\\chromedriver\\chromedriver.exe");
                driver = new ChromeDriver();

            } else if (browsername.equals("IE")) {
                System.setProperty("webdriver.ie.driver", "P:\\Selenium_Project\\chromedriver_win32\\IEDriverServer.exe");
                driver = new InternetExplorerDriver();

            }

            driver.manage().window().maximize();
            driver.manage().deleteAllCookies();
            driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_TIMEOUT, TimeUnit.SECONDS);
            System.out.println(prop.getProperty("URL"));
            driver.get(prop.getProperty("URL"));

        } catch (Exception e) {
            System.out.println("exception occured");
            e.printStackTrace();
        }

    }

}
