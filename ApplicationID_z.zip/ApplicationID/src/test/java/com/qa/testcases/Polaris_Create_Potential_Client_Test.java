package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.Polaris_Home_Page;
import com.qa.pages.Polaris_Potential_Client_Page;
import com.qa.util.TestUtil;

public class Polaris_Create_Potential_Client_Test extends TestBase {
    Polaris_Home_Page polarishomepage;
    Polaris_Potential_Client_Page polarispotentialclientpage;
    String sheetname = "PotentialClient";

    // Initialize Parent class constructor
    public Polaris_Create_Potential_Client_Test() {
        super();
    }

    @BeforeMethod
    public void setup() {
        Initialization();
        polarishomepage = new Polaris_Home_Page();
        polarispotentialclientpage = new Polaris_Potential_Client_Page();

    }

    @DataProvider
    public Object[][] PotentialClientdata() {
        Object data[][] = TestUtil.getTestData(sheetname);
        return data;
    }

    @Test(priority = 1, dataProvider = "PotentialClientdata")
    public void deleteContact(String Client) throws InterruptedException {

        polarishomepage.waitfornavigation();
        polarishomepage.selectLanguage();
        Assert.assertEquals(polarishomepage.languageSelected().toString(), prop.getProperty("Language"));
        polarishomepage.selectSGR(prop.getProperty("SGR").toString());
        polarishomepage.selectRole();

        // polarishomepage.waitfornavigation();
        // polarishomepage.selectLanguage();
        // Assert.assertEquals(polarishomepage.languageSelected().toString(), prop.getProperty("Language"));
        polarispotentialclientpage.createnewcontact(Client);

        Assert.assertTrue(polarispotentialclientpage.validateClient(Client));
    }

    @AfterMethod
    public void closebrowser() {

        driver.quit();
    }

}
