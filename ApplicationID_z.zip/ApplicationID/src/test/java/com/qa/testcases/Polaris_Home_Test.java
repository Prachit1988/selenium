
package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.Polaris_Home_Page;
import com.qa.util.WebEventListener;

@Listeners(WebEventListener.class)
public class Polaris_Home_Test extends TestBase {

    Polaris_Home_Page polarishomepage;

    // Initialise Parent class constructor
    public Polaris_Home_Test() {
        super();
    }

    @BeforeMethod
    public void setup() {
        Initialization();
        polarishomepage = new Polaris_Home_Page();

    }

    @Test(priority = 1)
    public void PolarisHomePageTest() throws InterruptedException {

        polarishomepage.waitfornavigation();
        String _pageTitle = polarishomepage.ValidateTitleofPagePolaris();
        System.out.println(driver.getTitle());
        System.out.println("Polaris" + " " + prop.getProperty("Version"));

        Assert.assertEquals(_pageTitle, prop.getProperty("ApplicationName") + " " + prop.getProperty("Version"));
        Assert.assertTrue(polarishomepage.validateLogo());
        Assert.assertTrue(polarishomepage.validateLanguage());
        Assert.assertTrue(polarishomepage.validateOnlinePresence());

    }

    @AfterMethod
    public void closebrowser() {

        driver.quit();
    }

}
