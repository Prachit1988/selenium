package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.CRMHome;
import com.qa.pages.ContactsPage;
import com.qa.pages.LoginPage;
import com.qa.util.TestUtil;

public class CreateContactsTest extends TestBase{

	
	LoginPage loginPage;
	CRMHome crmhome;
	TestUtil testutil;
	ContactsPage contacts;
	
	String sheetname = "Contacts";

	//Initialize Parent class constructor
	public CreateContactsTest()
	{
		super();
	}
	
	@BeforeMethod
	public void setup()
	{
		Initialization();
		loginPage = new LoginPage();
		crmhome = new CRMHome();
		contacts = new ContactsPage();
		loginPage.loginmethod(prop.getProperty("email"), prop.getProperty("password"));
		//loginPage.loginmethod(_useremail, _userpassword)
	}
	
	@DataProvider
	public Object[][] Contactdata()
	{
		Object data[][] = TestUtil.getTestData(sheetname);
		return data;
	}
	
	
	@Test(priority=1, dataProvider = "Contactdata")
	public void createcontact(String FirstName, String MiddleName,String LastName ,String Description,String Email,String Department,String Status,String Category)
	{
		
		crmhome.clickContactlink();
		contacts.createnewcontact(FirstName, MiddleName, LastName, Description, Email, Department, Status, Category);
		String username =  (FirstName+" "+LastName);
		Assert.assertEquals(contacts.checkusercreated().toString(), username);
	}
	
	
	@AfterMethod
	public void closebrowser()
	{
		crmhome.clickLogout();
		driver.quit();
	}
}
