package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.Polaris_Home_Page;
import com.qa.util.WebEventListener;

@Listeners(WebEventListener.class)
public class Polaris_Language_SGR_Test extends TestBase {

    Polaris_Home_Page polarishomepage;
    // Polaris_Home_Test polarishometest;

    // Initialise Parent class constructor
    public Polaris_Language_SGR_Test() {
        super();
    }

    @BeforeMethod
    public void setup() {
        Initialization();
        polarishomepage = new Polaris_Home_Page();
        // polarishometest = new Polaris_Home_Test();
        // polarishometest.PolarisHomePageTest();

    }

    @Test(priority = 1)
    public void Select_Language_SGR_Test() throws InterruptedException {

        polarishomepage.waitfornavigation();
        polarishomepage.selectLanguage();
        Assert.assertEquals(polarishomepage.languageSelected().toString(), prop.getProperty("Language"));
        polarishomepage.selectSGR(prop.getProperty("SGR").toString());
        polarishomepage.selectRole();

    }

    @AfterMethod
    public void closebrowser() {

        driver.quit();
    }

}
