/*
 * Creation : 3 Mar 2020
 */
package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.Polaris_Home_Page;
import com.qa.pages.Polaris_Industrial_Mean_Page;
import com.qa.pages.Polaris_Potential_Client_Page;
import com.qa.util.TestUtil;
import com.qa.util.WebEventListener;

@Listeners(WebEventListener.class)
public class Polaris_Delete_Industrial_Mean_Test extends TestBase {

    Polaris_Home_Page polarishomepage;
    Polaris_Potential_Client_Page polarispotentialclientpage;
    Polaris_Industrial_Mean_Page polarisindustrialmeanpage;

    String sheetname = "IndustrialMean";

    // Initialise Parent class constructor
    public Polaris_Delete_Industrial_Mean_Test() {
        super();
    }

    @BeforeMethod
    public void setup() {
        Initialization();
        polarishomepage = new Polaris_Home_Page();
        polarisindustrialmeanpage = new Polaris_Industrial_Mean_Page();

    }

    @DataProvider
    public Object[][] IndustrialMean() {
        Object data[][] = TestUtil.getTestData(sheetname);
        return data;
    }

    @Test(priority = 1, dataProvider = "IndustrialMean")
    public void Select_Create_Industrial_Mean_Test(String Code, String Supply, String Description, String Type, String Topology, String Sector,
            String FamilyDependentRate, String SnOPCriticalMeans, String MPSConstraintActivation, String ManufacturingLeadtime, String MPSCode,
            String ChildCode, String ChildSupply, String ChildDesc, String SeqType) throws InterruptedException {

        // Prerequisite Test
        polarishomepage.waitfornavigation();
        polarishomepage.selectLanguage();
        Assert.assertEquals(polarishomepage.languageSelected().toString(), prop.getProperty("Language"));
        polarishomepage.selectSGR(prop.getProperty("SGR").toString());
        polarishomepage.selectRole();

        // Delete Industrial Mean
        polarisindustrialmeanpage.clickDeleteButton(Code);
        Assert.assertTrue(polarisindustrialmeanpage.validateIMDeleted(Code));

    }

    @AfterMethod
    public void closebrowser() {

        // driver.quit();
    }

}
