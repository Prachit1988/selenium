package com.qa.testcases;



import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.CRMHome;
import com.qa.pages.ContactsPage;
import com.qa.pages.LoginPage;
import com.qa.util.TestUtil;

public class LoginPageTest extends TestBase{
	
	LoginPage loginPage;
	CRMHome crmhome;
	static TestUtil testutil;
	ContactsPage contacts;
	
	String sheetname = "Login";

	//Initialize Parent class constructor
	public LoginPageTest()
	{
		super();
	}
	
	@BeforeMethod
	public void setup()
	{
		Initialization();
		loginPage = new LoginPage();
		crmhome = new CRMHome();
		contacts = new ContactsPage();
	}
	
	@DataProvider
	public Object[][] Logindata()
	{
		Object data[][] = TestUtil.getTestData(sheetname);
		return data;
	}
	
	@Test(priority=1, dataProvider = "Logindata")
	public void LoginPageTitleTest(String UserName, String Password)
	{
		//Verify the Window open
		String _pageTitle = loginPage.ValidateTitleofPage();
		Assert.assertEquals(_pageTitle, "CRM");
		
		//Enter Credentials and login
		loginPage.loginmethod(prop.getProperty("email"), prop.getProperty("password"));
	}
	
	
	@AfterMethod
	public void closebrowser()
	{
		crmhome.clickLogout();
		driver.quit();
	}
	
	
}
