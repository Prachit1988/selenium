package com.qa.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.CRMHome;
import com.qa.pages.ContactsPage;
import com.qa.pages.LoginPage;
import com.qa.util.CommonActions;
import com.qa.util.TestUtil;

public class DeleteContactTest extends TestBase{
	LoginPage loginPage;
	CRMHome crmhome;
	TestUtil testutil;
	ContactsPage contacts;
	String sheetname = "Contacts";
	//Initialize Parent class constructor
	public DeleteContactTest()
	{
		super();
	}
		
	@BeforeMethod
	public void setup()
	{
		Initialization();
		loginPage = new LoginPage();
		crmhome = new CRMHome();
		contacts = new ContactsPage();
		loginPage.loginmethod(prop.getProperty("email"), prop.getProperty("password"));
	}
	
	@DataProvider
	public Object[][] Contactdata()
	{
		Object data[][] = TestUtil.getTestData(sheetname);
		return data;
	}
	
	
	@Test(priority=1)
	public void deleteContact()
	{
		crmhome.clickContactlink();
		
		contacts.SelectandDeleteActiondropdown();
		
		
		
	}
	
	
	
	@AfterMethod
	public void closebrowser()
	{
		//crmhome.clickLogout();
		//driver.quit();
	}

}
