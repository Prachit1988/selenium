package com.qa.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.pages.CRMHome;
import com.sun.media.sound.InvalidFormatException;


public class TestUtil {
	
	public static long PAGE_LOAD_TIMEOUT = 20000;
	public static long IMPLICIT_TIMEOUT = 20000;
	public static WebDriver driver;
	CRMHome crmhome;
	
	
	public static String TESTDATA_SHEET_PATH = "C:\\Selenium_Project\\ApplicationID\\src\\main\\java\\com\\qa\\testdata\\freeCRMData.xlsx";
			

	static Workbook book;
	static Sheet sheet;
	static JavascriptExecutor js;
	

	// This will take screenshots
	public static void takeScreenshotAtEndOfTest() throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String currentDir = System.getProperty("user.dir");
		FileUtils.copyFile(scrFile, new File(currentDir + "/screenshots/" + System.currentTimeMillis() + ".png"));
	}
	
	
		
	//Extract data from excelsheet and insert in application
	public static Object[][] getTestData(String sheetName) {
		FileInputStream file = null;
		try {
			file = new FileInputStream(TESTDATA_SHEET_PATH);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = book.getSheet(sheetName);
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		// System.out.println(sheet.getLastRowNum() + "--------" +
		// sheet.getRow(0).getLastCellNum());
		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
				data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
				// System.out.println(data[i][k]);
			}
		}
		return data;
	}
	

	
	public void switchToFrame()
	{
		driver.switchTo().frame("");
	}
	

	public void IndexPageNotLoaded(WebElement _element, String _xpath) 
	{
		try 
		{
		boolean element2 = driver.findElement(By.xpath(_xpath)).isEnabled();

			if (element2 = true) 
			{
				System.out.println(element2 + "element found successfully.");
				
			}else if (element2 = false) 
			{
				Thread.sleep(5000);
				driver.navigate().refresh();
				System.out.println(element2 + "element not found.");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} 

}
}
