package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;
import com.qa.util.TestUtil;

public class LoginPage extends TestBase{
	
	LoginPage loginPage;
	CRMHome crmhome;
	TestUtil testutil;
	
	//Page Factory
	
			@FindBy(xpath="//input[@name='email']")
			@CacheLookup
			WebElement _emailaddress;
			
			@FindBy(xpath="//input[@name='password']")
			@CacheLookup
			WebElement _password;
			
			@FindBy(xpath="//div[@class='ui fluid large blue submit button']")
			@CacheLookup
			WebElement _loginButton;
			
						
			
			// Initialize the Page Objects
			public LoginPage()
			{
				PageFactory.initElements(driver, this);
			}
			
			
			//Validate Page Title
			public String ValidateTitleofPage()
			{
				System.out.println(driver.getTitle());
				return driver.getTitle();
			}
			
			//Login button enable
			public boolean validateSignup()
			{
				return _loginButton.isDisplayed();
			}
			
			
			//Login Function
			public CRMHome loginmethod(String _useremail, String _userpassword) 
			{
				_emailaddress.isEnabled();
				_emailaddress.sendKeys(_useremail);
				_password.isEnabled();
				_password.sendKeys(_userpassword);
			    _loginButton.isEnabled();
				_loginButton.click();
				return new CRMHome();
			}

}
