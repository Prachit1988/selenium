package com.qa.pages;

import com.qa.base.TestBase;

public class TaskPage extends TestBase{

}
