package com.qa.pages;

import org.omg.CORBA.DomainManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.TestBase;
import com.qa.util.TestUtil;
import com.qa.util.CommonActions;

public class ContactsPage extends TestBase{
	

	
	@FindBy(xpath="//span[contains(text(),'Contacts')]")
	@CacheLookup
	WebElement contactslink;
	
	@FindBy(xpath="//button[@class='ui linkedin button']//i[@class='edit icon']")
	@CacheLookup
	WebElement newbtn;
	
	@FindBy(xpath="//div[contains(text(),'Create New Contact')]")
	@CacheLookup
	WebElement first;
	
	@FindBy(xpath="//input[@name='first_name']")
	@CacheLookup
	WebElement firstname;
	
	@FindBy(xpath="//input[@name='last_name']")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(xpath="//input[@name='middle_name']")
	@CacheLookup
	WebElement middlename;
	

	@FindBy(xpath="//textarea[@name='description']")
	@CacheLookup
	WebElement descriptiontxt;
	
	
	@FindBy(xpath="//div[@class='ui right corner labeled input']//input[@name='value']")
	@CacheLookup
	WebElement emailtxt;
	
	@FindBy(xpath="//button[@class=\"ui linkedin button\"]")
	@CacheLookup
	WebElement savebtn;
	
	
	@FindBy(xpath="//i[@class='large user red icon']")
	@CacheLookup
	WebElement username;
	
	@FindBy(xpath="//div[@class='ui header item mb5 light-black']")
	@CacheLookup
	WebElement userlbl;
	
	@FindBy(xpath="//div[@class='ui basic icon left attached button']")
	@CacheLookup
	WebElement checkbtn;
	
	@FindBy(xpath="//input[@name='department']")
	@CacheLookup
	WebElement departmenttxt;;
	

	@FindBy(xpath="//div[@name='status']")
	@CacheLookup
	WebElement statusDropdown;
	
	@FindBy(xpath="//div[@name='category']")
	@CacheLookup
	WebElement categoryDropdown;
	
	
	//Delete contact   
	
	@FindBy(xpath="//i[@class='checkmark icon']")
	@CacheLookup
	WebElement checkicon;
	
	@FindBy(xpath="//div[@class='ui selection upward dropdown']")
	@CacheLookup
	WebElement actionDD;
	
	
	@FindBy(xpath="//div[text()='Confirm']")
	@CacheLookup
	WebElement confirmlbl;
	
	
	@FindBy(xpath="//button[@class='ui primary button']")
	@CacheLookup
	WebElement deletebtn;
	
	@FindBy(xpath="//span[contains(text(),'Delete')]")
	@CacheLookup
	WebElement deleteact;
	
	
	// Initialize the Page Objects
	public ContactsPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	//Login button enable
	public boolean validatecontact()
	{
		return contactslink.isDisplayed();
	}
	
	public void waitforcontact()
	{
		CommonActions.waitforcontrol(driver, newbtn);
	}
	
	public void createnewcontact(String first, String middle,String last ,String desc,String email,String dep,String status, String category)
	{
		try {
		newbtn.isEnabled();
		newbtn.click();
		firstname.isEnabled();
		firstname.sendKeys(first);
		middlename.isEnabled();
		middlename.sendKeys(middle);
		lastname.isEnabled();
		lastname.sendKeys(last);
		descriptiontxt.isEnabled();
		descriptiontxt.sendKeys(desc);
		emailtxt.isEnabled();
		emailtxt.sendKeys(email);
		departmenttxt.isEnabled();
		departmenttxt.sendKeys(dep);

		CommonActions.SelectDropdown(driver, statusDropdown, status);
		
		CommonActions.SelectDropdown(driver, categoryDropdown, category);
		
		savebtn.isEnabled();
		savebtn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public String checkusercreated()
	{
		CommonActions.waitforcontrol(driver, userlbl);
		return userlbl.getText();
	}
	
	
	public void SelectandDeleteActiondropdown()
	{
		try {
			
		
		String delete = "Delete";
		CommonActions.SelectDropdown(driver, actionDD, delete);
		checkicon.isEnabled();
		checkicon.click();
		CommonActions.waitforcontrol(driver, confirmlbl);
		deletebtn.isEnabled();
		deletebtn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	


}
